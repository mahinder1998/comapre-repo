(function () {
  'use strict';

  window.Currency = window.Currency || {};

  var Currency$1 = function () {
    var formatString;

    function formatMoney(cents, format) {
      if (typeof cents === 'string') {
        cents = cents.replace('.', '');
      }

      var value = '';
      var placeholderRegex = /\{\{\s*(\w+)\s*\}\}/; // if (langify.locale.iso_code === "en") {
      //     formatString = format || 'Dhs. {{amount}}';
      // } else {
      //     formatString = format || '{{amount}} ر.س';
      // }

      formatString = format || 'Dhs. {{amount}}';

      function formatWithDelimiters(number, precision, thousands, decimal) {
        thousands = thousands || ',';
        decimal = decimal || '.';

        if (isNaN(number) || number === null) {
          return 0;
        }

        number = (number / 100.0).toFixed(precision);
        var parts = number.split('.');
        var dollarsAmount = parts[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, '$1' + thousands);
        var centsAmount = parts[1] ? decimal + parts[1] : '';
        return dollarsAmount + centsAmount;
      }

      switch (formatString.match(placeholderRegex)[1]) {
        case 'amount':
          value = formatWithDelimiters(cents, 2);
          break;

        case 'amount_no_decimals':
          value = formatWithDelimiters(cents, 0);
          break;

        case 'amount_with_comma_separator':
          value = formatWithDelimiters(cents, 2, '.', ',');
          break;

        case 'amount_no_decimals_with_comma_separator':
          value = formatWithDelimiters(cents, 0, '.', ',');
          break;

        case 'amount_no_decimals_with_space_separator':
          value = formatWithDelimiters(cents, 0, ' ');
          break;

        case 'amount_with_apostrophe_separator':
          value = formatWithDelimiters(cents, 2, "'");
          break;
      }

      return formatString.replace(placeholderRegex, value);
    }

    return {
      formatMoney: formatMoney
    };
  }();

  window.Currency = Currency$1;

  var MediaGallery = function () {
    return {
      init: function init() {
        $('.pdp__media__master__slider').slick({
          dots: false,
          arrows: true,
          fade: true,
          prevArrow: $('.pdp__media__master__slider__arrow.pdp__media__master__slider__arrow-prev'),
          nextArrow: $('.pdp__media__master__slider__arrow.pdp__media__master__slider__arrow-next')
        });
        $('.pdp__media__thumbs__slider').slick({
          slidesToShow: 4,
          slidesToScroll: 1,
          dots: false,
          arrows: false,
          asNavFor: '.pdp__media__master__slider',
          focusOnSelect: true
        });
      }
    };
  }();

  window.MediaGallery = MediaGallery;

  var PDPListeners = function () {
    function addToCart() {
      document.querySelector('.pdp__content__control__add-to-cart-btn').addEventListener('click', function () {
        document.querySelector('.pdpmodal-addedtocart__overlay').style.display = "block";
        document.querySelector('.pdpmodal-addedtocart__modal').style.display = "block";
      });
      document.querySelector('.pdpmodal-addedtocart__overlay').addEventListener('click', function () {
        document.querySelector('.pdpmodal-addedtocart__overlay').style.display = "none";
        document.querySelector('.pdpmodal-addedtocart__modal').style.display = "none";
      });
      document.querySelector('.pdpmodal-addedtocart__modal').addEventListener('click', function () {});
    }

    function pdpAddedToCartModalListeners() {
      document.querySelector('.pdpmodal-addedtocart__modal__checkout').addEventListener('click', function () {
        location.assign('/cart');
      });
      document.querySelector('.pdpmodal-addedtocart__modal__continue').addEventListener('click', function () {
        document.querySelector('.pdpmodal-addedtocart__overlay').style.display = "none";
        document.querySelector('.pdpmodal-addedtocart__modal').style.display = "none";
      });
    }

    function countListeners() {
      var countAdd = document.querySelector('.pdp__content__control__qty__next');
      var countRemove = document.querySelector('.pdp__content__control__qty__prev');
      var countValue = document.querySelector('.pdp__content__control__qty__value');
      countAdd.addEventListener('click', function () {
        var currentCount = parseInt(countValue.innerHTML.slice());
        currentCount = currentCount + 1;
        countValue.innerHTML = currentCount;
      });
      countRemove.addEventListener('click', function () {
        var currentCount = parseInt(countValue.innerHTML.slice());

        if (currentCount != 1) {
          currentCount = currentCount - 1;
          countValue.innerHTML = currentCount;
        }
      });
    }

    function accordionListeners() {
      var buttons = document.querySelectorAll('.pdp__content__accordion__header');
      buttons.forEach(function (button) {
        button.addEventListener('click', function () {
          // remove is-open from all the bodies
          document.querySelectorAll('.pdp__content__accordion__body').forEach(function (body) {
            body.classList.remove('is-open');
          });
          document.querySelectorAll('.pdp__content__accordion__icon').forEach(function (icon) {
            icon.classList.remove('is-open');
          }); // add is-open to selected body

          var body = this.nextElementSibling;
          body && body.classList.add('is-open');
          var cloestArrowIcon = this.querySelector('.pdp__content__accordion__icon');
          cloestArrowIcon && cloestArrowIcon.classList.add('is-open');
        });
      });
    }

    function swatchListeners() {
      var swatches = document.querySelectorAll('.pdp__content__swatches__item');
      swatches && swatches.forEach(function (swatch) {
        swatch.addEventListener('click', function (e) {
          var selectedOption = e.target.dataset.option;
          console.log("Selected Option is : " + selectedOption); // Get Selected Variant using data-option attribute.

          var variants = window.objectData.product && window.objectData.product.variants;
          var selectedVariant = variants.find(function (v) {
            return v.option1 == selectedOption;
          });
          console.log("Selected Varaint is ");
          console.log(selectedVariant); //Change the swatch active.

          swatches.forEach(function (swatch) {
            swatch.classList.remove('active');
          });
          this.classList.add('active'); //Change the title, size, price.

          document.querySelector('.pdp__content__price').innerHTML = Currency.formatMoney(selectedVariant.price);
          document.querySelector('.pdp__content__size').innerHTML = selectedVariant.option1; // Change the size label in mobile

          document.querySelector('.pdp__info-mobile__size').innerHTML = selectedVariant.option1; //Change data-id on CTAButtons;

          document.querySelector('.pdp__content__control__add-to-cart-btn') ? document.querySelector('.pdp__content__control__add-to-cart-btn').dataset.id = selectedVariant.id : null;
          document.querySelector('.pdp__content__control__notify-me-btn') ? document.querySelector('.pdp__content__control__notify-me-btn').dataset.id = selectedVariant.id : null; //Update the Sliders.

          var medias = window.objectData.product.media;
          var meidaFilterText = "__".concat(selectedOption, "__");
          var selectedImages = medias.filter(function (item) {
            return item.alt && item.alt.includes(meidaFilterText);
          });
          console.log(selectedImages);
          var masterGalleryHTMLString = "";
          selectedImages.forEach(function (img) {
            var htmlString = "\n                        <div class=\"pdp__media__master__slide\">\n                            <img src=\"".concat(img.src, "\" alt=\"\" class=\"pdp__media__master__slide__img\">\n                        </div>\n                    ");
            masterGalleryHTMLString = masterGalleryHTMLString + htmlString;
          });

          if (masterGalleryHTMLString) {
            $('.pdp__media__master__slider').slick('unslick');
            $('.pdp__media__thumbs__slider').slick('unslick');
            document.querySelector('.pdp__media__master__slider').innerHTML = masterGalleryHTMLString;
            document.querySelector('.pdp__media__thumbs__slider').innerHTML = masterGalleryHTMLString;
            $('.pdp__media__master__slider').slick({
              dots: false,
              arrows: true,
              fade: true,
              prevArrow: $('.pdp__media__master__slider__arrow.pdp__media__master__slider__arrow-prev'),
              nextArrow: $('.pdp__media__master__slider__arrow.pdp__media__master__slider__arrow-next')
            });
            $('.pdp__media__thumbs__slider').slick({
              slidesToShow: 4,
              slidesToScroll: 1,
              dots: false,
              arrows: false,
              asNavFor: '.pdp__media__master__slider',
              focusOnSelect: true
            });
          } // Update the CTA button on variant availablity


          document.querySelector('.pdp__content__control');
          var ctaAddToCart = document.querySelector('.pdp__content__control__add-to-cart-btn');
          var ctaNotifyMe = document.querySelector('.pdp__content__control__notify-me-btn');

          if (selectedVariant.available) {
            ctaNotifyMe.style.display = "none";
            ctaAddToCart.style.display = "grid";
          } else {
            ctaAddToCart.style.display = "none";
            ctaNotifyMe.style.display = "grid";
          }
        });
      });
    }

    return {
      init: function init() {
        countListeners();
        accordionListeners();
        swatchListeners();
        pdpAddedToCartModalListeners();
        addToCart();
      }
    };
  }();

  document.addEventListener('DOMContentLoaded', function () {
    PDPListeners.init();
    MediaGallery.init();
  });
  $(document).ready(function () {
    $('li.has-subs').hover(function () {
      $('html').addClass('nav-is-ready');
      $(this).addClass('link-is-active');
    }, function () {
      $('html').removeClass('nav-is-ready');
      $(this).removeClass('link-is-active');
    });
    /* Mobile Nav */

    $('.mb-burger-icon').click(function (e) {
      $('html').toggleClass('overh');
      $('#mb-mob-nav-cont').toggleClass('hide show');
      $('a[nav-lvl-three="ok"]').parent().parent().addClass('show');
      $('a[nav-lvl-three="ok"]').parent().parent().parent().find('.togglenewmob.lvltwomob span.mobile-nav__label').addClass('bold');
      $('a[nav-lvl-three="ok"]').parent().parent().parent().find('.togglenewmob.lvltwomob .mobile-nav__icon').addClass('mobchiv-up');
      $('a[nav-lvl-two="ok"]').parent().parent().addClass('show');
      $('a[nav-lvl-a="ok"][aria-current="page"]').parent().parent().parent('.li-lvlone').find('.togglenewmob.lvlonemob span.mobile-nav__label').addClass('bold');
      $('a[nav-lvl-a="ok"][aria-current="page"]').parent().parent().parent('.li-lvlone').find('.togglenewmob.lvlonemob .mobile-nav__icon').addClass('mobchiv-up');
      $('a[nav-lvl-a="ok"][aria-current="page"]').parent().parent().parent('.li-lvlone').find('ul.innercontent[data-level="2"]').addClass('show');
      $('a[nav-lvl-a="ok"][aria-current="page"]').parent().parent().parent('.li-lvlone').find('ul.innercontent[data-level="2"] li').siblings('.li-lvltwo').first().find('.togglenewmob.lvltwomob .mobile-nav__icon').addClass('mobchiv-up');
      $('a[nav-lvl-a="ok"][aria-current="page"]').parent().parent().parent('.li-lvlone').find('ul.innercontent[data-level="2"] li').siblings('.li-lvltwo').first().find('.togglenewmob.lvltwomob span.mobile-nav__label').addClass('bold');
      $('a[nav-lvl-a="ok"][aria-current="page"]').parent().parent().parent('.li-lvlone').find('ul.innercontent[data-level="2"] li').siblings('.li-lvltwo').first().find('ul.innercontent[data-level="3"]').addClass('show');
    });
    $('#mob-mnu-close').click(function (e) {
      $('html').toggleClass('overh');
      $('#MobileNav').toggleClass('hide show');
    });
    $('.togglenewmob').click(function (e) {
      e.preventDefault();
      var $this = $(this);

      if ($this.next().hasClass('show')) {
        $this.next().removeClass('show');
      } else {
        $this.parent().parent().find('li .innercontent').removeClass('show');
        $this.next().toggleClass('show');
      }
    });
    $('.lvlonemob').click(function (e) {
      e.preventDefault();
      $('.li-lvltwo span.mobile-nav__label').removeClass("bold");
      $('.li-lvltwo .lvltwomob-chiv').removeClass('mobchiv-up');

      if ($(this).find('.lvlonemob-chiv').hasClass('mobchiv-up')) {
        $('.mobile-nav__label').removeClass("bold");
        $('.lvlonemob-chiv').removeClass('mobchiv-up');
      } else {
        $('.lvlonemob-chiv').removeClass('mobchiv-up');
        $('.lvlonemob .mobile-nav__label').removeClass("bold");
        $(this).find('.mobile-nav__label').addClass("bold");
        $(this).find('.lvlonemob-chiv').addClass("mobchiv-up");
      }

      $(this).parent('.li-lvlone').find('ul.innercontent[data-level="2"] li').siblings('.li-lvltwo').first().find('ul.innercontent[data-level="3"]').addClass('show');
      $(this).parent('.li-lvlone').find('ul.innercontent[data-level="2"] li').siblings('.li-lvltwo').first().find('.togglenewmob.lvltwomob .mobile-nav__label').addClass('bold');
      $(this).parent('.li-lvlone').find('ul.innercontent[data-level="2"] li').siblings('.li-lvltwo').first().find('.togglenewmob.lvltwomob .mobile-nav__icon').addClass('mobchiv-up');
    });
    $('.lvltwomob').click(function (e) {
      e.preventDefault();

      if ($(this).find('.lvltwomob-chiv').hasClass('mobchiv-up')) {
        $('.lvltwomob .mobile-nav__label').removeClass("bold");
        $('.lvltwomob-chiv').removeClass('mobchiv-up');
      } else {
        $('.lvltwomob-chiv').removeClass('mobchiv-up');
        $('.lvltwomob .mobile-nav__label').removeClass("bold");
        $(this).find('.mobile-nav__label').addClass("bold");
        $(this).find('.lvltwomob-chiv').addClass("mobchiv-up");
      }
    });
    /* End Mobile Nav */

    $(function (e) {
      $(".addqty").click(function () {
        var currentVal = parseInt($(this).prev(".qtycart").val());

        if (currentVal != NaN) {
          $(this).prev(".qtycart").val(currentVal + 1);
        }
      });
      $(".minusqty").click(function () {
        var currentVal = parseInt($(this).next(".qtycart").val());

        if (currentVal != NaN) {
          if (currentVal > 0) {
            $(this).next(".qtycart").val(currentVal - 1);
          }
        }
      });
    });
    $('.mb-cart-flex').click(function () {
      $('.mini-cart-content').toggleClass('hide');
    });

    if ($(window).width() < 750) {
      $(".footer-header").click(function () {
        if ($(this).parents(".footer-item").hasClass("active-item")) {
          $(".footer-item").removeClass("active-item");
          $(".footer-body").slideUp("slow");
        } else {
          $(".footer-item").removeClass("active-item");
          $(".footer-body").slideUp("slow");
          $(this).parents(".footer-item").addClass("active-item");
          $(this).next(".footer-body").slideDown("slow");
        }
      });
    } // Account address code here


    $("#AddressNewButton").click(function () {
      $("#AddressNewForm").toggle();
    });
    $(".toggle-password").click(function () {
      $(this).toggleClass("fa-eye fa-eye-slash");
      var input = $('.password-splash');

      if (input.attr("type") == "password") {
        input.attr("type", "text");
      } else {
        input.attr("type", "password");
      }
    });
    $(".toggle-password-conf").click(function () {
      $(this).toggleClass("fa-eye fa-eye-slash");
      var input = $('.password-splash-conf');

      if (input.attr("type") == "password") {
        input.attr("type", "text");
      } else {
        input.attr("type", "password");
      }
    });
    var inputError = false;
    $(".password-splash-conf").on('keyup', function (event) {
      if (event.target.value != document.getElementById('RegisterForm-password').value) {
        console.log('ppp');
        inputError = true;
      } else {
        inputError = false;
        $('error-msg').hide();
      }
    });
    $(document).on('click', function (event) {
      if (inputError) {
        $('.error-msg').show();
      }
    }); // cart page cart note count

    $("#CartSpecialInstructions").on('keyup', function () {
      $("#countcharacter").text(250 - $(this).val().length + " Characters");
    }); // search box toggle js

    $("#searchbar .search-label").on("click", function (e) {
      e.preventDefault();
      $("#searchbar").toggleClass("collapsed");
    }); // product search js

    $(".search-input").bind("keyup", function (e) {
      if (this.value.length < 3) {
        // console.log(this.value.length);
        //$("#productData").html('');
        //$("#viewResults").html('');
        $(".search-result-weap").hide();
      } else if (this.value.length >= 3) {
        var searchKeyword = this.value; //$(".search-result-weap").show();
      }

      jQuery.getJSON("/search/suggest.json", {
        q: searchKeyword,
        resources: {
          type: "product",
          options: {
            unavailable_products: "last",
            fields: "title,product_type,variants.title"
          }
        }
      }).done(function (response) {
        var productSuggestions = response.resources.results.products;
        var pro_length = productSuggestions.length; //console.log(finalColldata.id);

        if (productSuggestions.length > 0) {
          var str = "";
          var show_counter = 1;

          for (i = 0; i < pro_length; i++) {
            if (show_counter <= 3) {
              $(".search-result-weap").show();
              var firstProductSuggestion = productSuggestions[i];
              str += '<a href="' + firstProductSuggestion.url + '" class="search-result-items"><div class="get-product-image"><img src="' + firstProductSuggestion.image + '"></div>' + '<div class="get-product-title">' + firstProductSuggestion.title + "</div>" + '<div class="get-product-price">' + firstProductSuggestion.price + "</div></a>"; //console.log("The title of the first product suggestion is: " + firstProductSuggestion.id);
              //console.log(firstProductSuggestion.title);

              show_counter = show_counter + 1;
            }
          }

          $(".productData").html(str);

          if (pro_length > 3) {
            $(".viewResults").html("More Results");
          }

          $(".customSearchredirect").attr("href", "https://molton-dev.myshopify.com/search?q=" + searchKeyword + "&type=product");
        }
      });
    }); // account page tab js

    $(".tabs-main li").click(function () {
      var tab_id = $(this).attr("data-tab");
      $(".tabs-main li").removeClass("current");
      $(".tabs-items").removeClass("current");
      $(this).addClass("current");
      $("." + tab_id).addClass("current");
    });
    $(".template-customers-addresses .tabs-main li.current").click(function () {
      $(".template-customers-addresses .my_address").addClass("current");
    }); // customer order tab

    var url = window.location.href;
    var pageURL = url.split("#").pop();
    pageURL.split("+"); //alert(pageURL);

    if (pageURL == "my_order") {
      $(".tab-link").removeClass("current");
      $(".tabs-items").removeClass("current");
      $("#my_order").parent().addClass("current");
      $(".my_order").addClass("current");
    }
  });
  /* End Doc ready */
})();
//# sourceMappingURL=theme.js.map
