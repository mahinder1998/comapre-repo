(function () {
  'use strict';

  window.Currency = window.Currency || {};

  var Currency = function () {
    var formatString;

    function formatMoney(cents, format) {
      if (typeof cents === 'string') {
        cents = cents.replace('.', '');
      }

      var value = '';
      var placeholderRegex = /\{\{\s*(\w+)\s*\}\}/; // if (langify.locale.iso_code === "en") {
      //     formatString = format || 'Dhs. {{amount}}';
      // } else {
      //     formatString = format || '{{amount}} ر.س';
      // }

      formatString = format || 'Dhs. {{amount}}';

      function formatWithDelimiters(number, precision, thousands, decimal) {
        thousands = thousands || ',';
        decimal = decimal || '.';

        if (isNaN(number) || number === null) {
          return 0;
        }

        number = (number / 100.0).toFixed(precision);
        var parts = number.split('.');
        var dollarsAmount = parts[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, '$1' + thousands);
        var centsAmount = parts[1] ? decimal + parts[1] : '';
        return dollarsAmount + centsAmount;
      }

      switch (formatString.match(placeholderRegex)[1]) {
        case 'amount':
          value = formatWithDelimiters(cents, 2);
          break;

        case 'amount_no_decimals':
          value = formatWithDelimiters(cents, 0);
          break;

        case 'amount_with_comma_separator':
          value = formatWithDelimiters(cents, 2, '.', ',');
          break;

        case 'amount_no_decimals_with_comma_separator':
          value = formatWithDelimiters(cents, 0, '.', ',');
          break;

        case 'amount_no_decimals_with_space_separator':
          value = formatWithDelimiters(cents, 0, ' ');
          break;

        case 'amount_with_apostrophe_separator':
          value = formatWithDelimiters(cents, 2, "'");
          break;
      }

      return formatString.replace(placeholderRegex, value);
    }

    return {
      formatMoney: formatMoney
    };
  }();

  window.Currency = Currency;

  var MediaGallery = function () {
    return {
      init: function init() {
        $('.pdp__media__master__slider').slick({
          dots: false,
          arrows: true,
          fade: true,
          prevArrow: $('.pdp__media__master__slider__arrow.pdp__media__master__slider__arrow-prev'),
          nextArrow: $('.pdp__media__master__slider__arrow.pdp__media__master__slider__arrow-next')
        });
        $('.pdp__media__thumbs__slider').slick({
          slidesToShow: 4,
          slidesToScroll: 1,
          dots: false,
          arrows: false,
          asNavFor: '.pdp__media__master__slider',
          focusOnSelect: true
        });
      }
    };
  }();

  window.MediaGallery = MediaGallery;
  document.addEventListener('DOMContentLoaded', function () {
    MediaGallery.init(); // SparxScripts.init();
    // PDPListeners.init();
  });
})();
//# sourceMappingURL=theme.js.map
