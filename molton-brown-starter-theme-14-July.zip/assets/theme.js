function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

(function () {
  'use strict';

  function getDefaultRequestConfig() {
    return JSON.parse(JSON.stringify({
      credentials: 'same-origin',
      headers: {
        'X-Requested-With': 'XMLHttpRequest',
        'Content-Type': 'application/json;'
      }
    }));
  }

  function fetchJSON(url, config) {
    return fetch(url, config).then(function (response) {
      if (!response.ok) {
        throw response;
      }

      return response.json();
    });
  }

  function cart$1() {
    return fetchJSON('/cart.js', getDefaultRequestConfig());
  }

  function cartAdd(id, quantity, properties) {
    var config = getDefaultRequestConfig();
    config.method = 'POST';
    config.body = JSON.stringify({
      id: id,
      quantity: quantity,
      properties: properties
    });
    return fetchJSON('/cart/add.js', config);
  }

  function cartAddFromForm(formData) {
    var config = getDefaultRequestConfig();
    delete config.headers['Content-Type'];
    config.method = 'POST';
    config.body = formData;
    return fetchJSON('/cart/add.js', config);
  }

  function cartChange(line, options) {
    var config = getDefaultRequestConfig();
    options = options || {};
    config.method = 'POST';
    config.body = JSON.stringify({
      line: line,
      quantity: options.quantity,
      properties: options.properties
    });
    return fetchJSON('/cart/change.js', config);
  }

  function cartClear() {
    var config = getDefaultRequestConfig();
    config.method = 'POST';
    return fetchJSON('/cart/clear.js', config);
  }

  function cartUpdate(body) {
    var config = getDefaultRequestConfig();
    config.method = 'POST';
    config.body = JSON.stringify(body);
    return fetchJSON('/cart/update.js', config);
  }

  function cartShippingRates() {
    return fetchJSON('/cart/shipping_rates.json', getDefaultRequestConfig());
  }

  function key(key) {
    if (typeof key !== 'string' || key.split(':').length !== 2) {
      throw new TypeError('Theme Cart: Provided key value is not a string with the format xxx:xxx');
    }
  }

  function quantity(quantity) {
    if (typeof quantity !== 'number' || isNaN(quantity)) {
      throw new TypeError('Theme Cart: An object which specifies a quantity or properties value is required');
    }
  }

  function id(id) {
    if (typeof id !== 'number' || isNaN(id)) {
      throw new TypeError('Theme Cart: Variant ID must be a number');
    }
  }

  function properties(properties) {
    if (_typeof(properties) !== 'object') {
      throw new TypeError('Theme Cart: Properties must be an object');
    }
  }

  function form(form) {
    if (!(form instanceof HTMLFormElement)) {
      throw new TypeError('Theme Cart: Form must be an instance of HTMLFormElement');
    }
  }

  function options(options) {
    if (_typeof(options) !== 'object') {
      throw new TypeError('Theme Cart: Options must be an object');
    }

    if (typeof options.quantity === 'undefined' && typeof options.properties === 'undefined') {
      throw new Error('Theme Cart: You muse define a value for quantity or properties');
    }

    if (typeof options.quantity !== 'undefined') {
      quantity(options.quantity);
    }

    if (typeof options.properties !== 'undefined') {
      properties(options.properties);
    }
  }
  /**
   * Cart Template Script
   * ------------------------------------------------------------------------------
   * A file that contains scripts highly couple code to the Cart template.
   *
   * @namespace cart
   */

  /**
   * Returns the state object of the cart
   * @returns {Promise} Resolves with the state object of the cart (https://help.shopify.com/en/themes/development/getting-started/using-ajax-api#get-cart)
   */


  function getState() {
    return cart$1();
  }
  /**
   * Returns the index of the cart line item
   * @param {string} key The unique key of the line item
   * @returns {Promise} Resolves with the index number of the line item
   */


  function getItemIndex(key$1) {
    key(key$1);
    return cart$1().then(function (state) {
      var index = -1;
      state.items.forEach(function (item, i) {
        index = item.key === key$1 ? i + 1 : index;
      });

      if (index === -1) {
        return Promise.reject(new Error('Theme Cart: Unable to match line item with provided key'));
      }

      return index;
    });
  }
  /**
   * Fetches the line item object
   * @param {string} key The unique key of the line item
   * @returns {Promise} Resolves with the line item object (See response of cart/add.js https://help.shopify.com/en/themes/development/getting-started/using-ajax-api#add-to-cart)
   */


  function getItem(key$1) {
    key(key$1);
    return cart$1().then(function (state) {
      var lineItem = null;
      state.items.forEach(function (item) {
        lineItem = item.key === key$1 ? item : lineItem;
      });

      if (lineItem === null) {
        return Promise.reject(new Error('Theme Cart: Unable to match line item with provided key'));
      }

      return lineItem;
    });
  }
  /**
   * Add a new line item to the cart
   * @param {number} id The variant's unique ID
   * @param {object} options Optional values to pass to /cart/add.js
   * @param {number} options.quantity The quantity of items to be added to the cart
   * @param {object} options.properties Line item property key/values (https://help.shopify.com/en/themes/liquid/objects/line_item#line_item-properties)
   * @returns {Promise} Resolves with the line item object (See response of cart/add.js https://help.shopify.com/en/themes/development/getting-started/using-ajax-api#add-to-cart)
   */


  function addItem(id$1, options) {
    options = options || {};
    id(id$1);
    return cartAdd(id$1, options.quantity, options.properties);
  }
  /**
   * Add a new line item to the cart from a product form
   * @param {object} form DOM element which is equal to the <form> node
   * @returns {Promise} Resolves with the line item object (See response of cart/add.js https://help.shopify.com/en/themes/development/getting-started/using-ajax-api#add-to-cart)
   */


  function addItemFromForm(form$1) {
    form(form$1);
    var formData = new FormData(form$1);
    id(parseInt(formData.get('id'), 10));
    return cartAddFromForm(formData);
  }
  /**
   * Changes the quantity and/or properties of an existing line item.
   * @param {string} key The unique key of the line item (https://help.shopify.com/en/themes/liquid/objects/line_item#line_item-key)
   * @param {object} options Optional values to pass to /cart/add.js
   * @param {number} options.quantity The quantity of items to be added to the cart
   * @param {object} options.properties Line item property key/values (https://help.shopify.com/en/themes/liquid/objects/line_item#line_item-properties)
   * @returns {Promise} Resolves with the state object of the cart (https://help.shopify.com/en/themes/development/getting-started/using-ajax-api#get-cart)
   */


  function updateItem(key$1, options$1) {
    key(key$1);
    options(options$1);
    return getItemIndex(key$1).then(function (line) {
      return cartChange(line, options$1);
    });
  }
  /**
   * Removes a line item from the cart
   * @param {string} key The unique key of the line item (https://help.shopify.com/en/themes/liquid/objects/line_item#line_item-key)
   * @returns {Promise} Resolves with the state object of the cart (https://help.shopify.com/en/themes/development/getting-started/using-ajax-api#get-cart)
   */


  function removeItem(key$1) {
    key(key$1);
    return getItemIndex(key$1).then(function (line) {
      return cartChange(line, {
        quantity: 0
      });
    });
  }
  /**
   * Sets all quantities of all line items in the cart to zero. This does not remove cart attributes nor the cart note.
   * @returns {Promise} Resolves with the state object of the cart (https://help.shopify.com/en/themes/development/getting-started/using-ajax-api#get-cart)
   */


  function clearItems() {
    return cartClear();
  }
  /**
   * Gets all cart attributes
   * @returns {Promise} Resolves with the cart attributes object
   */


  function getAttributes() {
    return cart$1().then(function (state) {
      return state.attributes;
    });
  }
  /**
   * Sets all cart attributes
   * @returns {Promise} Resolves with the cart state object
   */


  function updateAttributes(attributes) {
    return cartUpdate({
      attributes: attributes
    });
  }
  /**
   * Clears all cart attributes
   * @returns {Promise} Resolves with the cart state object
   */


  function clearAttributes() {
    return getAttributes().then(function (attributes) {
      for (var key in attributes) {
        attributes[key] = '';
      }

      return updateAttributes(attributes);
    });
  }
  /**
   * Gets cart note
   * @returns {Promise} Resolves with the cart note string
   */


  function getNote() {
    return cart$1().then(function (state) {
      return state.note;
    });
  }
  /**
   * Sets cart note
   * @returns {Promise} Resolves with the cart state object
   */


  function updateNote(note) {
    return cartUpdate({
      note: note
    });
  }
  /**
   * Clears cart note
   * @returns {Promise} Resolves with the cart state object
   */


  function clearNote() {
    return cartUpdate({
      note: ''
    });
  }
  /**
   * Get estimated shipping rates.
   * @returns {Promise} Resolves with response of /cart/shipping_rates.json (https://help.shopify.com/en/themes/development/getting-started/using-ajax-api#get-shipping-rates)
   */


  function getShippingRates() {
    return cartShippingRates();
  }

  var cart = /*#__PURE__*/Object.freeze({
    __proto__: null,
    getState: getState,
    getItemIndex: getItemIndex,
    getItem: getItem,
    addItem: addItem,
    addItemFromForm: addItemFromForm,
    updateItem: updateItem,
    removeItem: removeItem,
    clearItems: clearItems,
    getAttributes: getAttributes,
    updateAttributes: updateAttributes,
    clearAttributes: clearAttributes,
    getNote: getNote,
    updateNote: updateNote,
    clearNote: clearNote,
    getShippingRates: getShippingRates
  });
  window.Currency = window.Currency || {};

  var Currency$1 = function () {
    var formatString;

    function formatMoney(cents, format) {
      if (typeof cents === 'string') {
        cents = cents.replace('.', '');
      }

      var value = '';
      var placeholderRegex = /\{\{\s*(\w+)\s*\}\}/; // if (langify.locale.iso_code === "en") {
      //     formatString = format || 'Dhs. {{amount}}';
      // } else {
      //     formatString = format || '{{amount}} ر.س';
      // }

      formatString = format || '{{amount}} AED';

      function formatWithDelimiters(number, precision, thousands, decimal) {
        thousands = thousands || ',';
        decimal = decimal || '.';

        if (isNaN(number) || number === null) {
          return 0;
        }

        number = (number / 100.0).toFixed(precision);
        var parts = number.split('.');
        var dollarsAmount = parts[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, '$1' + thousands);
        var centsAmount = parts[1] ? decimal + parts[1] : '';
        return dollarsAmount + centsAmount;
      }

      switch (formatString.match(placeholderRegex)[1]) {
        case 'amount':
          value = formatWithDelimiters(cents, 2);
          break;

        case 'amount_no_decimals':
          value = formatWithDelimiters(cents, 0);
          break;

        case 'amount_with_comma_separator':
          value = formatWithDelimiters(cents, 2, '.', ',');
          break;

        case 'amount_no_decimals_with_comma_separator':
          value = formatWithDelimiters(cents, 0, '.', ',');
          break;

        case 'amount_no_decimals_with_space_separator':
          value = formatWithDelimiters(cents, 0, ' ');
          break;

        case 'amount_with_apostrophe_separator':
          value = formatWithDelimiters(cents, 2, "'");
          break;
      }

      return formatString.replace(placeholderRegex, value);
    }

    return {
      formatMoney: formatMoney
    };
  }();

  window.Currency = Currency$1;

  var MediaGallery = function () {
    function renderSlide(slide) {
      console.log(slide);
      var slideHTML = "\n            <div class=\"pdp__media__master__slide\">\n                <img src=\"".concat(slide === null || slide === void 0 ? void 0 : slide.src, "\" alt=\"\" class=\"pdp__media__master__slide__img\">\n            </div>\n        ");
      document.querySelector('.pdp__media__master__slider').insertAdjacentHTML("beforeend", slideHTML);
    }

    function renderThumb(slide) {
      var slideHTML = "\n            <div class=\"pdp__media__thumbs__slide\">\n                <img src=\"".concat(slide === null || slide === void 0 ? void 0 : slide.src, "\" alt=\"\" class=\"pdp__media__master__slide__img\">\n            </div>\n        ");
      document.querySelector('.pdp__media__thumbs__slider').insertAdjacentHTML("beforeend", slideHTML);
    }

    function renderMasterSlides(images) {
      document.querySelector('.pdp__media__master__slider').innerHTML = "";
      images.forEach(function (slide) {
        return renderSlide(slide);
      });
    }

    function renderThumbSlides(images) {
      document.querySelector('.pdp__media__thumbs__slider').innerHTML = "";
      images.forEach(function (slide) {
        return renderThumb(slide);
      });
    }

    function initSlides() {
      $('.pdp__media__master__slider').slick({
        dots: false,
        arrows: true,
        fade: true,
        prevArrow: $('.pdp__media__master__slider__arrow.pdp__media__master__slider__arrow-prev'),
        nextArrow: $('.pdp__media__master__slider__arrow.pdp__media__master__slider__arrow-next')
      });
      $('.pdp__media__thumbs__slider').slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        dots: false,
        arrows: false,
        asNavFor: '.pdp__media__master__slider',
        focusOnSelect: true
      });
    }

    function showSlides() {
      document.querySelector('.pdp__media__shimmer').style.display = "none";
      document.querySelector('.pdp__media__master').style.display = "block";
      document.querySelector('.pdp__media__thumbs').style.display = "block";
    }

    return {
      init: function init() {
        if (objectData.product) {
          if (objectData.hasOnlyDefaultVariant) {
            initSlides();
            showSlides();
          } else {
            var _objectData, _objectData$product, _objectData2, _objectData2$selected, _objectData2$selected2;

            var medias = (_objectData = objectData) === null || _objectData === void 0 ? void 0 : (_objectData$product = _objectData.product) === null || _objectData$product === void 0 ? void 0 : _objectData$product.media;
            var currentAlt = (_objectData2 = objectData) === null || _objectData2 === void 0 ? void 0 : (_objectData2$selected = _objectData2.selectedVaraint) === null || _objectData2$selected === void 0 ? void 0 : (_objectData2$selected2 = _objectData2$selected.featured_image) === null || _objectData2$selected2 === void 0 ? void 0 : _objectData2$selected2.alt;
            var currentVariantImages = medias === null || medias === void 0 ? void 0 : medias.filter(function (media) {
              return media.alt == currentAlt;
            });
            renderMasterSlides(currentVariantImages);
            renderThumbSlides(currentVariantImages);
            initSlides();
            showSlides();
          }
        }
      }
    };
  }();

  window.MediaGallery = MediaGallery;

  var PDPListeners = function () {
    // Selectors
    var selectors = {
      headerCartBubble: ".mcart-count",
      addToCartButtonLoading: ".pdp__content__control__add-to-cart-btn__loading",
      addToCartButtonLabel: ".pdp__content__control__add-to-cart-btn__label",
      qtyElem: ".pdp__content__control__qty__value",
      accordionItem: ".pdp__content__accordions__item",
      accordionBody: ".pdp__content__accordions__item__body",
      accordionHeading: ".pdp__content__accordions__item__heading",
      accordionArrow: ".pdp__content__list__heading__arrow"
    }; // Update the variant

    function resetCount() {
      if (document.querySelector(selectors.qtyElem)) {
        document.querySelector(selectors.qtyElem).innerHTML = 1;
      }
    } //Update the header cart count.


    function updateBubble(quantity) {
      var currentCount = null;

      if (document.querySelector(selectors.headerCartBubble)) {
        currentCount = parseInt(document.querySelector(selectors.headerCartBubble).innerHTML);
        console.log("current count " + currentCount);

        if (quantity) {
          var newCount = currentCount + quantity;
          document.querySelector(selectors.headerCartBubble).innerHTML = newCount;
        } else {
          document.querySelector(selectors.headerCartBubble).innerHTML = currentCount;
        }
      }
    } // Show error message


    function showError(message) {
      var errorBox = document.querySelector('.pdp__content__error');
      var errorText = document.querySelector('.pdp__content__error__text');
      errorText.innerHTML = message || "There was an errro adding product to the cart.";
      errorBox.style.display = "flex";
    } // Hide error message 


    function hideError() {
      var errorBox = document.querySelector('.pdp__content__error');
      errorBox.style.display = "none";
    } // Show Add to cart button laoder 


    function showLoaderAddToCartButton() {
      if (document.querySelector(selectors.addToCartButtonLabel)) {
        document.querySelector(selectors.addToCartButtonLabel).style.display = "none";
      }

      if (document.querySelector(selectors.addToCartButtonLoading)) {
        document.querySelector(selectors.addToCartButtonLoading).style.display = "block";
      }
    } // Hide loader in add to cart button.


    function hideLoaderAddToCartButton() {
      if (document.querySelector(selectors.addToCartButtonLabel)) {
        document.querySelector(selectors.addToCartButtonLabel).style.display = "block";
      }

      if (document.querySelector(selectors.addToCartButtonLoading)) {
        document.querySelector(selectors.addToCartButtonLoading).style.display = "none";
      }
    } // Open Added to cart modal.


    function openAddedtoCartModal(title, image, quantity, price, size) {
      if (title && document.querySelector('.pdpmodal-addedtocart__modal__body__content__title')) {
        document.querySelector('.pdpmodal-addedtocart__modal__body__content__title').innerHTML = title;
      }

      if (image && document.querySelector('.pdpmodal-addedtocart__modal__body__media__img')) {
        document.querySelector('.pdpmodal-addedtocart__modal__body__media__img').src = image;
      }

      if (quantity && document.querySelector('.pdpmodal-addedtocart__modal__body__content__qty__value')) {
        document.querySelector('.pdpmodal-addedtocart__modal__body__content__qty__value').innerHTML = quantity;
      }

      if (price && document.querySelector('.pdpmodal-addedtocart__modal__body__content__price')) {
        document.querySelector('.pdpmodal-addedtocart__modal__body__content__price').innerHTML = price;
      }

      if (size && document.querySelector('.pdpmodal-addedtocart__modal__body__content__size__value')) {
        document.querySelector('.pdpmodal-addedtocart__modal__body__content__size__value').innerHTML = size;
        document.querySelector('.pdpmodal-addedtocart__modal__body__content__size').style.display = "flex";
      }

      document.querySelector('.pdpmodal-addedtocart__overlay').style.display = "block";
      document.querySelector('.pdpmodal-addedtocart__modal').style.display = "block";
    }

    function addToCart() {
      // Add to cart button click
      if (document.querySelector('.pdp__content__control__add-to-cart-btn')) {
        document.querySelector('.pdp__content__control__add-to-cart-btn').addEventListener('click', function (e) {
          var _e$target, _e$target$closest$dat;

          // Show loader
          hideError();
          showLoaderAddToCartButton(); //Get id and quantity

          var variantIdString = e.target.dataset.id || (e === null || e === void 0 ? void 0 : (_e$target = e.target) === null || _e$target === void 0 ? void 0 : (_e$target$closest$dat = _e$target.closest('.pdp__content__control__add-to-cart-btn').dataset) === null || _e$target$closest$dat === void 0 ? void 0 : _e$target$closest$dat.id);
          var variantId = parseInt(variantIdString);
          var quantityString = document.querySelector(selectors.qtyElem).innerHTML;
          var quantity = quantityString ? parseInt(quantityString) : 1; // Add item to the cart.

          Cart.addItem(variantId, {
            quantity: quantity
          }).then(function (res) {
            console.log(res);
            var title = res.product_title;
            var image = res.featured_image.url || res.image;
            var price = Currency.formatMoney(parseFloat(res.price) * parseFloat(quantity));
            var size = null;

            if (!res.product_has_only_default_variant) {
              size = res.variant_options[0];
            } // Reset counter 


            resetCount(); // Update the bubble

            updateBubble(quantity); // Show added modal

            openAddedtoCartModal(title, image, quantity, price, size); // Hide loader 

            hideLoaderAddToCartButton();
          })["catch"](function (err) {
            //Error
            console.log("Error adding the product.");
            console.log(err); // Hide loader 

            hideLoaderAddToCartButton();
            showError();
          });
        });
      } // Added to cart overlay click - close


      if (document.querySelector('.pdpmodal-addedtocart__overlay')) {
        document.querySelector('.pdpmodal-addedtocart__overlay').addEventListener('click', function () {
          document.querySelector('.pdpmodal-addedtocart__overlay').style.display = "none";
          document.querySelector('.pdpmodal-addedtocart__modal').style.display = "none";
        });
      } // Disable click on modal from closing


      if (document.querySelector('.pdpmodal-addedtocart__modal')) {
        document.querySelector('.pdpmodal-addedtocart__modal').addEventListener('click', function () {});
      }
    }

    function pdpAddedToCartModalListeners() {
      if (document.querySelector('.pdpmodal-addedtocart__modal__checkout')) {
        document.querySelector('.pdpmodal-addedtocart__modal__checkout').addEventListener('click', function () {
          location.assign('/cart');
        });
      }

      if (document.querySelector('.pdpmodal-addedtocart__modal__continue')) {
        document.querySelector('.pdpmodal-addedtocart__modal__continue').addEventListener('click', function () {
          document.querySelector('.pdpmodal-addedtocart__overlay').style.display = "none";
          document.querySelector('.pdpmodal-addedtocart__modal').style.display = "none";
        });
      }
    }

    function countListeners() {
      var countAdd = document.querySelector('.pdp__content__control__qty__next');
      var countRemove = document.querySelector('.pdp__content__control__qty__prev');
      var countValue = document.querySelector('.pdp__content__control__qty__value');
      countAdd && countAdd.addEventListener('click', function () {
        var currentCount = parseInt(countValue.innerHTML.slice());
        currentCount = currentCount + 1;
        countValue.innerHTML = currentCount;
      });
      countRemove && countRemove.addEventListener('click', function () {
        var currentCount = parseInt(countValue.innerHTML.slice());

        if (currentCount != 1) {
          currentCount = currentCount - 1;
          countValue.innerHTML = currentCount;
        }
      });
    } // const masterGalleryHTMLString = `
    //     <div class="pdp__media__master__slide">
    //         <img src="{{ image | img_url: '500x', scale: 2 }}" alt="" class="pdp__media__master__slide__img">
    //     </div>
    // `;


    function swatchListeners() {
      var swatches = document.querySelectorAll('.pdp__content__swatches__item');
      swatches && swatches.forEach(function (swatch) {
        swatch.addEventListener('click', function (e) {
          var selectedOption = e.target.dataset.option;
          console.log("Selected Option is : " + selectedOption); // Get Selected Variant using data-option attribute.

          var variants = window.objectData.product && window.objectData.product.variants;
          var selectedVariant = variants.find(function (v) {
            return v.option1 == selectedOption;
          });
          console.log("Selected Varaint is ");
          console.log(selectedVariant); //Change the swatch active.

          swatches.forEach(function (swatch) {
            swatch.classList.remove('active');
          });
          this.classList.add('active'); //Change the title, size, price.

          document.querySelector('.pdp__content__price').innerHTML = Currency.formatMoney(selectedVariant.price);
          document.querySelector('.pdp__content__size').innerHTML = selectedVariant.option1; // Change the size label in mobile

          document.querySelector('.pdp__info-mobile__size').innerHTML = selectedVariant.option1; //Change data-id on CTAButtons;

          document.querySelector('.pdp__content__control__add-to-cart-btn') ? document.querySelector('.pdp__content__control__add-to-cart-btn').dataset.id = selectedVariant.id : null;
          document.querySelector('.pdp__content__control__notify-me-btn') ? document.querySelector('.pdp__content__control__notify-me-btn').dataset.id = selectedVariant.id : null; //Update the Sliders.

          var medias = window.objectData.product.media;
          var meidaFilterText = "__".concat(selectedOption, "__");
          var selectedImages = medias.filter(function (item) {
            return item.alt && item.alt.includes(meidaFilterText);
          });
          console.log(selectedImages);
          var masterGalleryHTMLString = "";
          selectedImages.forEach(function (img) {
            var htmlString = "\n                        <div class=\"pdp__media__master__slide\">\n                            <img src=\"".concat(img.src, "\" alt=\"\" class=\"pdp__media__master__slide__img\">\n                        </div>\n                    ");
            masterGalleryHTMLString = masterGalleryHTMLString + htmlString;
          });

          if (masterGalleryHTMLString) {
            $('.pdp__media__master__slider').slick('unslick');
            $('.pdp__media__thumbs__slider').slick('unslick');
            document.querySelector('.pdp__media__master__slider').innerHTML = masterGalleryHTMLString;
            document.querySelector('.pdp__media__thumbs__slider').innerHTML = masterGalleryHTMLString;
            $('.pdp__media__master__slider').slick({
              dots: false,
              arrows: true,
              fade: true,
              prevArrow: $('.pdp__media__master__slider__arrow.pdp__media__master__slider__arrow-prev'),
              nextArrow: $('.pdp__media__master__slider__arrow.pdp__media__master__slider__arrow-next')
            });
            $('.pdp__media__thumbs__slider').slick({
              slidesToShow: 4,
              slidesToScroll: 1,
              dots: false,
              arrows: false,
              asNavFor: '.pdp__media__master__slider',
              focusOnSelect: true
            });
          } // Update the CTA button on variant availablity


          document.querySelector('.pdp__content__control');
          var ctaAddToCart = document.querySelector('.pdp__content__control__add-to-cart-btn');
          var ctaNotifyMe = document.querySelector('.pdp__content__control__notify-me-btn');

          if (selectedVariant.available) {
            ctaNotifyMe.style.display = "none";
            ctaAddToCart.style.display = "grid";
          } else {
            ctaAddToCart.style.display = "none";
            ctaNotifyMe.style.display = "grid";
          }
        });
      });
    } // PDP accordion


    function accordion() {
      var customAccordions = document.querySelectorAll(selectors.accordionHeading);
      console.log(customAccordions);
      customAccordions && customAccordions.forEach(function (accordion) {
        accordion.addEventListener('click', function (e) {
          console.log(e.target);
          var body = e.target.closest(selectors.accordionItem).querySelector(selectors.accordionBody);

          if (body.classList.contains('active')) {
            body.classList.remove('active');
            gsap.to(body, {
              height: 0
            });
          } else {
            body.classList.add('active');
            gsap.to(body, {
              height: "auto"
            });
          }
        });
      });
    }

    return {
      init: function init() {
        countListeners();
        swatchListeners();
        pdpAddedToCartModalListeners();
        addToCart();
        accordion();
      }
    };
  }();

  var SparxScripts = function () {
    return {
      init: function init() {
        $(document).ready(function () {
          $('li.has-subs').hover(function () {
            $('html').addClass('nav-is-ready');
            $(this).addClass('link-is-active');
          }, function () {
            $('html').removeClass('nav-is-ready');
            $(this).removeClass('link-is-active');
          });
          /* Mobile Nav */

          $('.mb-burger-icon').click(function (e) {
            $('html').toggleClass('overh');
            $('#mb-mob-nav-cont').toggleClass('hide show');
            $('a[nav-lvl-three="ok"]').parent().parent().addClass('show');
            $('a[nav-lvl-three="ok"]').parent().parent().parent().find('.togglenewmob.lvltwomob span.mobile-nav__label').addClass('bold');
            $('a[nav-lvl-three="ok"]').parent().parent().parent().find('.togglenewmob.lvltwomob .mobile-nav__icon').addClass('mobchiv-up');
            $('a[nav-lvl-two="ok"]').parent().parent().addClass('show');
            $('a[nav-lvl-a="ok"][aria-current="page"]').parent().parent().parent('.li-lvlone').find('.togglenewmob.lvlonemob span.mobile-nav__label').addClass('bold');
            $('a[nav-lvl-a="ok"][aria-current="page"]').parent().parent().parent('.li-lvlone').find('.togglenewmob.lvlonemob .mobile-nav__icon').addClass('mobchiv-up');
            $('a[nav-lvl-a="ok"][aria-current="page"]').parent().parent().parent('.li-lvlone').find('ul.innercontent[data-level="2"]').addClass('show');
            $('a[nav-lvl-a="ok"][aria-current="page"]').parent().parent().parent('.li-lvlone').find('ul.innercontent[data-level="2"] li').siblings('.li-lvltwo').first().find('.togglenewmob.lvltwomob .mobile-nav__icon').addClass('mobchiv-up');
            $('a[nav-lvl-a="ok"][aria-current="page"]').parent().parent().parent('.li-lvlone').find('ul.innercontent[data-level="2"] li').siblings('.li-lvltwo').first().find('.togglenewmob.lvltwomob span.mobile-nav__label').addClass('bold');
            $('a[nav-lvl-a="ok"][aria-current="page"]').parent().parent().parent('.li-lvlone').find('ul.innercontent[data-level="2"] li').siblings('.li-lvltwo').first().find('ul.innercontent[data-level="3"]').addClass('show');
          });
          $('#mob-mnu-close').click(function (e) {
            $('html').toggleClass('overh');
            $('#MobileNav').toggleClass('hide show');
          });
          $('.togglenewmob').click(function (e) {
            e.preventDefault();
            var $this = $(this);

            if ($this.next().hasClass('show')) {
              $this.next().removeClass('show');
            } else {
              $this.parent().parent().find('li .innercontent').removeClass('show');
              $this.next().toggleClass('show');
            }
          });
          $('.lvlonemob').click(function (e) {
            e.preventDefault();
            $('.li-lvltwo span.mobile-nav__label').removeClass("bold");
            $('.li-lvltwo .lvltwomob-chiv').removeClass('mobchiv-up');

            if ($(this).find('.lvlonemob-chiv').hasClass('mobchiv-up')) {
              $('.mobile-nav__label').removeClass("bold");
              $('.lvlonemob-chiv').removeClass('mobchiv-up');
            } else {
              $('.lvlonemob-chiv').removeClass('mobchiv-up');
              $('.lvlonemob .mobile-nav__label').removeClass("bold");
              $(this).find('.mobile-nav__label').addClass("bold");
              $(this).find('.lvlonemob-chiv').addClass("mobchiv-up");
            }

            $(this).parent('.li-lvlone').find('ul.innercontent[data-level="2"] li').siblings('.li-lvltwo').first().find('ul.innercontent[data-level="3"]').addClass('show');
            $(this).parent('.li-lvlone').find('ul.innercontent[data-level="2"] li').siblings('.li-lvltwo').first().find('.togglenewmob.lvltwomob .mobile-nav__label').addClass('bold');
            $(this).parent('.li-lvlone').find('ul.innercontent[data-level="2"] li').siblings('.li-lvltwo').first().find('.togglenewmob.lvltwomob .mobile-nav__icon').addClass('mobchiv-up');
          });
          $('.lvltwomob').click(function (e) {
            e.preventDefault();

            if ($(this).find('.lvltwomob-chiv').hasClass('mobchiv-up')) {
              $('.lvltwomob .mobile-nav__label').removeClass("bold");
              $('.lvltwomob-chiv').removeClass('mobchiv-up');
            } else {
              $('.lvltwomob-chiv').removeClass('mobchiv-up');
              $('.lvltwomob .mobile-nav__label').removeClass("bold");
              $(this).find('.mobile-nav__label').addClass("bold");
              $(this).find('.lvltwomob-chiv').addClass("mobchiv-up");
            }
          });
          /* End Mobile Nav */

          $(function (e) {
            $(".addqty").click(function () {
              var currentVal = parseInt($(this).prev(".qtycart").val());

              if (currentVal != NaN) {
                $(this).prev(".qtycart").val(currentVal + 1);
              }
            });
            $(".minusqty").click(function () {
              var currentVal = parseInt($(this).next(".qtycart").val());

              if (currentVal != NaN) {
                if (currentVal > 1) {
                  $(this).next(".qtycart").val(currentVal - 1);
                }
              }
            });
          });
          $('.mb-cart-flex').click(function () {
            $('.mini-cart-content').toggleClass('hide');
          });
          $('.mb-cart-flex').click(function () {
            if ($('.mini-cart-content').hasClass("hide")) $('.mini-cart-content').removeClass('hide');else $('.mini-cart-content').addClass('hide');
          });
          $(document).on("click", function () {
            jQuery(".mini-cart-content").addClass("hide");
          });
          $(document).on("click", ".mb-cart-flex", function (event) {
            event.stopPropagation();
            event.stopImmediatePropagation();
            event.preventDefault();
          });
          $(".mb-dt-nav-cont li").hover(function () {
            jQuery(".mini-cart-content").addClass("hide");
          });
        });
        /* End Doc ready */
        // Sahid 

        $(document).ready(function () {
          if ($(window).width() < 750) {
            $(".footer-header").click(function () {
              if ($(this).parents(".footer-item").hasClass("active-item")) {
                $(".footer-item").removeClass("active-item");
                $(".footer-body").slideUp("slow");
              } else {
                $(".footer-item").removeClass("active-item");
                $(".footer-body").slideUp("slow");
                $(this).parents(".footer-item").addClass("active-item");
                $(this).next(".footer-body").slideDown("slow");
              }
            });
          } // Account address code here


          $("#AddressNewButton").click(function () {
            $("#AddressNewForm").toggle();
          });
        }); // Harshita 

        $(document).ready(function () {
          // search box toggle js
          $("#searchbar .search-label").on("click", function (e) {
            e.preventDefault();
            $("#searchbar").toggleClass("collapsed");
          }); // product search js

          $(".search-input").bind("keyup", function (e) {
            if (this.value.length < 3) {
              // console.log(this.value.length);
              //$("#productData").html('');
              //$("#viewResults").html('');
              $(".search-result-weap").hide();
            } else if (this.value.length >= 3) {
              var searchKeyword = this.value; //$(".search-result-weap").show();
            }

            jQuery.getJSON("/search/suggest.json", {
              q: searchKeyword,
              resources: {
                type: "product",
                options: {
                  unavailable_products: "last",
                  fields: "title,product_type,variants.title"
                }
              }
            }).done(function (response) {
              var productSuggestions = response.resources.results.products;
              var pro_length = productSuggestions.length; //console.log(finalColldata.id);

              if (productSuggestions.length > 0) {
                var str = "";
                var show_counter = 1;

                for (i = 0; i < pro_length; i++) {
                  if (show_counter <= 3) {
                    $(".search-result-weap").show();
                    var firstProductSuggestion = productSuggestions[i];
                    str += '<a href="' + firstProductSuggestion.url + '" class="search-result-items"><div class="get-product-image"><img src="' + firstProductSuggestion.image + '"></div>' + '<div class="get-product-title">' + firstProductSuggestion.title + "</div>" + '<div class="get-product-price">' + firstProductSuggestion.price + "</div></a>"; //console.log("The title of the first product suggestion is: " + firstProductSuggestion.id);
                    //console.log(firstProductSuggestion.title);

                    show_counter = show_counter + 1;
                  }
                }

                $(".productData").html(str);

                if (pro_length > 3) {
                  $(".viewResults").html("More Results");
                }

                $(".customSearchredirect").attr("href", "https://molton-dev.myshopify.com/search?q=" + searchKeyword + "&type=product");
              }
            });
          }); // account page tab js

          $(".tabs-main li").click(function () {
            var tab_id = $(this).attr("data-tab");
            $(".tabs-main li").removeClass("current");
            $(".tabs-items").removeClass("current");
            $(this).addClass("current");
            $("." + tab_id).addClass("current");
          });
          $(".template-customers-addresses .tabs-main li.current").click(function () {
            $(".template-customers-addresses .my_address").addClass("current");
          }); // customer order tab

          var url = window.location.href;
          var pageURL = url.split("#").pop();
          pageURL.split("+"); //alert(pageURL);

          if (pageURL == "my_order") {
            $(".tab-link").removeClass("current");
            $(".tabs-items").removeClass("current");
            $("#my_order").parent().addClass("current");
            $(".my_order").addClass("current");
          }
        }); // Deepak

        $(document).ready(function () {
          $(".toggle-password").click(function () {
            $(this).toggleClass("fa-eye fa-eye-slash");
            var input = $('.password-splash');

            if (input.attr("type") == "password") {
              input.attr("type", "text");
            } else {
              input.attr("type", "password");
            }
          });
          $(".toggle-password-conf").click(function () {
            $(this).toggleClass("fa-eye fa-eye-slash");
            var input = $('.password-splash-conf');

            if (input.attr("type") == "password") {
              input.attr("type", "text");
            } else {
              input.attr("type", "password");
            }
          });
          var inputError = false;
          $(".password-splash-conf").on('keyup', function (event) {
            if (event.target.value != document.getElementById('RegisterForm-password').value) {
              console.log('ppp');
              inputError = true;
            } else {
              inputError = false;
              $('error-msg').hide();
            }
          });
          $(document).on('click', function (event) {
            if (inputError) {
              $('.error-msg').show();
            }
          }); // cart page cart note count

          $("#CartSpecialInstructions").on('keyup', function () {
            $("#countcharacter").text(250 - $(this).val().length + " Characters");
          });
        });
        window.Currency = window.Currency || {};
        jQuery(document).on("click", ".updateqty", function (event) {
          var value = $(this).siblings('.cart-quantity').val();
          var itemIndex = $(this).attr('qty-index');

          _updateItemQuantity(itemIndex, value);
        });

        function _updateItemQuantity(itemIndex, value) {
          $.getJSON('/cart.js').then(function (cart) {
            $.ajax({
              type: 'POST',
              url: '/cart/change.js',
              data: {
                quantity: value,
                line: itemIndex
              },
              dataType: 'json',
              success: function success(item) {
                console.log(JSON.stringify(item));
                $('.mcart-count').html(item.item_count);
                var up_total_price = Currency.formatMoney(item.total_price);
                var item_price = Currency.formatMoney(item.items[itemIndex - 1].line_price);
                $('.cart_subtotal').html(up_total_price);
                $("[item-loop=item-" + itemIndex + "]").find('.cart-item-price p').html(item_price);
                $("[item-loop=item-" + itemIndex + "]").find('.price-cart-mob').html(item_price);
              }
            });
          });
        }

        $(document).ready(function () {
          // accordion js start
          $(".accordion_header").click(function () {
            if ($(this).parents(".accordion_items").hasClass("active-item")) {
              $(".accordion_items").removeClass("active-item");
              $(".accordion_body").slideUp("slow");
            } else {
              $(".accordion_items").removeClass("active-item");
              $(".accordion_body").slideUp("slow");
              $(this).parents(".accordion_items").addClass("active-item");
              $(this).next(".accordion_body").slideDown("slow");
            }
          });
        }); // jQuery(document).on("click",".register-footer .btn",function(event) {
        //   event.stopPropagation();
        //   jQuery(".register-overlay").show().addClass("open");
        //   jQuery(".model-content.reg-modal").show();
        // });

        jQuery(document).on("click", ".model-content.reg-modal .close-modal,.register-overlay", function (event) {
          event.stopPropagation();
          jQuery(".register-overlay").hide().removeClass("open");
          jQuery(".model-content.reg-modal").hide();
        });
      }
    };
  }();

  window.Cart = cart;
  document.addEventListener('DOMContentLoaded', function () {
    MediaGallery.init();
    SparxScripts.init();
    PDPListeners.init();
  });
})();
//# sourceMappingURL=theme.js.map
